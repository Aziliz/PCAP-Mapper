# Telemetry Registry Refactor

This build centralizes telemetry definitions in `app/telemetry/registry.py` and adds the `/telemetry` navigation page.

Implemented items:

- Central plugin registry used by ATT&CK coverage paths through `apply_registry_to_attack_globals()`.
- Built-in plugins remain in one registry file instead of being scattered across app modules.
- Custom plugins are stored in `results/telemetry_plugins.json`.
- Active/available plugin table with category dropdown including `All categories`.
- New Plugin section with Name, Category, Aliases, Observed Components, Potential Components, and Description fields.
- Inline plugin editing for built-in and custom plugins. Editing a built-in creates a custom override with the same name.
- Delete action removes custom plugins or disables built-ins.
- Enable/disable support.
- JSON import/export for plugin backups.
- Plugin validation for required fields, duplicate aliases, confidence values, and empty component mappings.
- Plugin test mode for pasted sample logs/text.
- Environment profile guidance.
- Plugin authoring guide.

Observed components should be evidence-backed capabilities. Potential components should represent capabilities available when the telemetry product is fully configured.
