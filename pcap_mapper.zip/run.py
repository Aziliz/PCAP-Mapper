import os
from app.web import app, start_services

if __name__ == "__main__":
    start_services()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")), threaded=True)
