#!/usr/bin/env python3
"""Verify complete MITRE ATT&CK Enterprise v18 technique/sub-technique rule coverage.

This script intentionally uses only the Python standard library and the app's
existing modules. It loads the official Enterprise ATT&CK v18 STIX bundle via
app.attack.stix_dataset, expands the built-in/generated/custom rule library,
and fails if any active v18 technique or sub-technique lacks a validating rule.
"""
import json
import os
import sys
from pathlib import Path

# Complete coverage requires the official STIX bundle. Do not silently fall back.
os.environ.setdefault("ATTACK_STIX_STRICT", "1")
os.environ.setdefault("ATTACK_STIX_AUTO_DOWNLOAD", "1")

from app.rules.engine import load_rules, attack_coverage_report, rule_conflicts
from app.attack.versioned import VALID_TECHNIQUES, ATTACK_DATASET_METADATA


def main() -> int:
    rules = load_rules(include_disabled=True)
    report = attack_coverage_report(rules)
    unresolved = [c for c in rule_conflicts(rules) if c.get("severity") not in {"info", "informational"}]

    out_dir = Path("results")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_json = out_dir / "official_attack_v18_complete_rule_coverage.json"
    out_md = out_dir / "OFFICIAL_ATTACK_V18_COMPLETE_RULE_COVERAGE.md"
    out_json.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")

    md = [
        "# Official MITRE ATT&CK Enterprise v18 Complete Rule Coverage",
        "",
        f"Dataset official: {bool(ATTACK_DATASET_METADATA.get('official'))}",
        f"Dataset source: {ATTACK_DATASET_METADATA.get('source')}",
        f"Dataset path: {ATTACK_DATASET_METADATA.get('path')}",
        f"STIX format: {ATTACK_DATASET_METADATA.get('stix_format')}",
        "",
        f"Total techniques verified: {report['total_techniques']}",
        f"Total sub-techniques verified: {report['total_subtechniques']}",
        f"Existing rules reused: {report['existing_rules_verified']}",
        f"New Detection Rules generated: {report['new_detection_rules_generated']}",
        f"New Network Rules generated: {report['new_network_rules_generated']}",
        f"Total rules generated: {report['total_rules_generated']}",
        f"Remaining uncovered techniques: {len(report['remaining_uncovered_techniques'])}",
        f"Remaining uncovered sub-techniques: {len(report['remaining_uncovered_subtechniques'])}",
        f"Unresolved rule conflicts: {len(unresolved)}",
        "",
        "## Coverage by tactic",
    ]
    for tactic, data in sorted(report.get("coverage_by_tactic", {}).items()):
        md.append(
            f"- {tactic}: {data.get('covered',0)}/{data.get('total',0)} covered "
            f"({data.get('techniques',0)} techniques, {data.get('subtechniques',0)} sub-techniques)"
        )
    md += ["", "## ATT&CK IDs"]
    for item in report.get("items", []):
        kind = "sub-technique" if item.get("is_subtechnique") else "technique"
        status = "existing" if item.get("existing_rule") else "generated" if item.get("newly_generated_rule") else "uncovered"
        md.append(f"- {item['id']} ({kind}) {item['name']} - {status} - {', '.join(item.get('rule_types') or [])}")
    out_md.write_text("\n".join(md), encoding="utf-8")

    failures = []
    if not ATTACK_DATASET_METADATA.get("official"):
        failures.append("Official Enterprise ATT&CK v18 STIX dataset was not loaded.")
    if report["remaining_uncovered_techniques"]:
        failures.append("Uncovered techniques: " + ", ".join(report["remaining_uncovered_techniques"]))
    if report["remaining_uncovered_subtechniques"]:
        failures.append("Uncovered sub-techniques: " + ", ".join(report["remaining_uncovered_subtechniques"]))
    if unresolved:
        failures.append(f"Unresolved rule conflicts: {len(unresolved)}")

    print(out_md)
    print(out_json)
    print(f"Total techniques verified: {report['total_techniques']}")
    print(f"Total sub-techniques verified: {report['total_subtechniques']}")
    print(f"Total existing rules reused: {report['existing_rules_verified']}")
    print(f"Total new Detection Rules created: {report['new_detection_rules_generated']}")
    print(f"Total new Network Rules created: {report['new_network_rules_generated']}")
    print(f"Total rules added: {report['total_rules_generated']}")
    print(f"Total rule conflicts resolved: {0 if not unresolved else 'FAILED: unresolved conflicts remain'}")

    if failures:
        print("\nFAIL:")
        for failure in failures:
            print("-", failure)
        return 1
    print("\nPASS: every official ATT&CK Enterprise v18 technique and sub-technique has at least one validating rule.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
