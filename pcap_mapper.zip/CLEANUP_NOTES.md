# Cleanup Notes

This cleanup was intentionally conservative and did not change the application architecture.

Removed from the codebase ZIP:

- Python bytecode caches (`__pycache__`, `*.pyc`)
- editor/runtime backup files (`*.bak`)
- one-off historical patch scripts that were not imported by the application

Code cleanup / correctness fixes:

- Fixed `attack_ids_from_text()` in `app/events/normalizer.py` so ATT&CK IDs use a real word-boundary regex (`\b`) instead of embedded backspace characters.
- Removed an older, superseded MITRE coverage color override block from `app/static/style.css` and kept the current v2.56 color block as the single source for observed/validated/covered colors.

Not changed:

- No route, template, parser, rule-engine, telemetry-registry, or coverage-model architecture was refactored.
- Duplicate historical function definitions in `app/attack/versioned.py` were left in place because some later overrides intentionally wrap earlier definitions. Removing them safely would require a dedicated architectural refactor.
